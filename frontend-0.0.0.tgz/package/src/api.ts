const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8092'
const TOKEN = import.meta.env.VITE_BEARER_TOKEN

export type Order = { id: string; amount: number; currency: string; status: string; providerOrderId?: string; orderReference?: string }
export type Payment = { id: string; amount: number; currency: string; status: string; method?: string; orderId?: string; email?: string }
export type Refund = { id: string; amount: number; currency: string; status: string; paymentId?: string; speedRequested?: string }
export type Settlement = { id: string; amount: number; status: string; fees: number; tax: number; utr?: string }
export type Downtime = { id: string; method: string; status: string; severity: string; instrument?: Record<string, unknown> }
export type Webhook = { id: string; url: string; active: boolean; events: string[]; alertEmail?: string }

async function request<T>(path: string, options?: RequestInit): Promise<T> {
    const headers = new Headers(options?.headers)
    headers.set('Accept', 'application/json')
    if (options?.body) headers.set('Content-Type', 'application/json')
    if (TOKEN) headers.set('Authorization', `Bearer ${TOKEN}`)
    const response = await fetch(`${API_BASE}${path}`, { ...options, headers })
    if (!response.ok) throw new Error(`${response.status} ${await response.text()}`)
    return response.json() as Promise<T>
}

export const api = {
    orders: () => request<Order[]>('/payments/orders'),
    payments: (orderId: string) => request<Payment[]>(`/payments/orders/${orderId}/payments`),
    refunds: (paymentId: string) => request<Refund[]>(`/payments/payments/${paymentId}/refunds`),
    settlements: () => request<{ items: Settlement[] }>('/payments/settlements'),
    downtimes: () => request<{ items: Downtime[] }>('/payments/downtimes'),
    webhooks: (accountId: string) => request<Webhook[]>(`/webhooks/${accountId}`),
}
